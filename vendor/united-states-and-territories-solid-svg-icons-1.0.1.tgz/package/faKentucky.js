'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'usat';
var iconName = 'kentucky';
var width = 512;
var height = 512;
var aliases = ["ky"];
var unicode = 'e913';
var svgPathData = 'm21.6 325.2-2-8.1 10-11.5 8-.8 26.8 14.8 7-7.4-6-11.7 3-8.8 13.8-5.3L96 285l-4.7-16.8 10.2-11.7 13-6.1 30.6-4.6 17.3 13.5 6-9.3 17.3-8 3 6.8 10.4 4 5.8-15.1 15.9-9.9 1.3 8.9 16.5 5.5 6.9-2.3 1.6-13.3 8-9.9 9-3 2.6-9 13.8-11.9-1.3-14.4 20.3 2.5 9.9-6.9 12.2-1.3.7-8.5-6.6-14.1 9.6-8.2 8.3 6 8.3-1.5 14 7.4 6.4 17.5 24 4 13 11 10.1-6.8 15.7 9 9.5-2.2 8-9.3 9.3-3.1 3.6 14 16.2 10 3.2 18.3-4 11 6.1 5.8 3.7 11.9 16.6 23 14.7 10.5-19 24.2-25.4 13.6-10.4 20.4-13.4 3.3-8.3 10.3-23.4 7-11 7.3-59.7-.4-45.6-2.3-44.6.2-35-2.7-106.3-.6-15.1-4.4.7 15.8L0 366.5l3.4-10 10.2 4.4 8.8-27.4Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faKentucky = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;