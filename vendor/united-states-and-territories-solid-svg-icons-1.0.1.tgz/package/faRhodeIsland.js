'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'usat';
var iconName = 'rhode-island';
var width = 384;
var height = 512;
var aliases = ["ri"];
var unicode = 'e92b';
var svgPathData = 'm344.6 247.1 10.1 4.8 22.4 5.4-3.8 38.1 4.8 8.9 5.9 65.6-8.4 2.5-1.2 7.2-28.3 18.9 1.9-19.3-8.5-10.3 2.9-10.5-4-10 1.7-8.3-5.7-4.4 5.4-32.7-5.3-21.5-13 4.4-1.5 22 3.9 8.7-.2 27 4.5 5.2-12.3 29.4-15.7-1.6-7.8 2.4.3 10.9-3.9 10-10-3.8-5.7 7.4-11.1-.7-2.7-9.7 23.2-9-6-28.6 8.6-2.6.3-16.9 19.1-41.6.8-11.8 10.7-10.2 7.5.2 9-10.6 5.7.3ZM0 492.8l16.2-15.3-4.2-16 2.6-15-5.5-12.9 12-9.3 11.7 1.9 6-165.6-5-193.4-.6-50.3 17-1.1L173 12.3l14.2-1.6 61-1.2v87l22.1-3.7-1 11.6 3.5 13.4-4.2 12.1 3.6 6.4-6.1 8.6 10 29.5 34.4 19.4 19 28.9-8.3 8.8 3.3 14-9.7 11.8-7.3 2.2-11.9-3.4-7.4 2.1 1.1-15.5 5.9-14.5-8.7-7 .4-6.1-16.7-2.2-.8-6.8-9.8-7.1-6-26.5L243 174l5.5 17.5v19.7l8.7 15.6-7 26.4-6.1-3.7-.4-8.4-30.8-1.6 2 14 11.4-2.8 8 4.9.1 28.5 2.6 22.6-18.1 5.5-1.8 12.2 12.8 19 1.4 13.8-3.4 12.3 1.6 18L223 405l-12.8 10 1.5 16-16.2 26.3-24.6-3.2-44.1 9.3-37.2 14-14.6 8-18.5 4-11.5-1.9-21.6 5.3-22 9.6Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faRhodeIsland = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;