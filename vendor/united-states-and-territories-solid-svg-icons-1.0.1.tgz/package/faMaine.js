'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'usat';
var iconName = 'maine';
var width = 384;
var height = 512;
var aliases = ["me"];
var unicode = 'e917';
var svgPathData = 'm216.5 377.4 5.7-5.6 8.2 7.5-12 5.7ZM49.2 512 39 504l1-13-12.4-12.5-.7-52.4-1.3-100.7-2.7-75.9 10.9-3.7 5.2 12.3 6.7-9.9-1.4-9.3 16.5-.4-7.5-10 6.2-13.4 14.8-11.4 4.1-10.3 11-8.8 3.6-8.3-6.2-9 6.5-14.2-4.2-5.8 7-16.2 12.3-9.6 5.1-32.7L175.2 0l14.9 5.3-.4 19.6 10.6 7 26-12h15.4l4.2-8.7 8.5 1.7L276 30l5.2 10 8 4.7 1 54.4 2 76.8-1.2 31 16 8 14.7 2.3-5.5 12.5 6.2 10-3.8 13.6 10.5 16.7 5-7 11 3 16 40.7-17 19.4-10-1.6-7.8 8-11.6-3.5-1.5 11-24.4 2-1.8 7.9-8.3 8-10.8-1.8-.3-7.7-15-.3 10.2 14.7-4 6.4-17.3-.8 3.8-15.7-15.2 4.7-5.4 12.6-14.9-10.1-1.8-9.8-13.6 4.2 3.4 11.5-8.7 13.5-3.2 14.6-8.9 16.5-13.3-6-6.3 2-5.6 16.1-8.5-2.4-19.3 16.2-3.3-7-12.3 1.1-2-7.9-12.1 7-5.6 10.3 4.4 14-14 4-.1 10.6L65.6 479 52 510.8Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faMaine = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;