'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'usat';
var iconName = 'illinois';
var width = 320;
var height = 512;
var aliases = ["il"];
var unicode = 'e910';
var svgPathData = 'm23.4 196.2 3.2-1.1 2.3-20.2 16-5.1 2.1-13.2 9.6-10.3 1.5-15.9-11.4-13.6 5-15.7L78.8 97l21.9-11.3 2.1-13.6 8.9-6.3 3.5-18.5-1.5-10.5-15.5-10.2-5.7-14.8L81.4 0l39 .5 87.9 1.8 67.3-.8-2 17.8L284.4 40l5.4 21.3 6 11.1 2.1 114 1.6 106.2-2.9 12-5.9 7.8 12.3 32.3-29 57.8-9 12.6 1.8 12.7-3.5 14.5-6.9 7 5.9 17.7-14.7 2-14.3 6.2-2.9 9.6 6.9 12.1-7.1 8.1-29.3-14.5-8.4 1.2-12.4 18.5-7 1.8-16.6-27.2 7.1-10.3-6.9-12.9.4-13.9-24.2-20.5-8 2-3.7-7.9-17.2-13.5-8-9.5-.9-11.7 13.1-23.9-1.3-10.4 7.2-12.7-9.8-6.6-14.4-4.7-6.8 8.5-8.5-5-4.1-30L47.1 281l-2.8-6.5-18.8-18.4-3.2-17-5-11.4-.3-18.6Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faIllinois = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;