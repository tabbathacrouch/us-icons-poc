'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'usat';
var iconName = 'maryland';
var width = 512;
var height = 512;
var aliases = ["md"];
var unicode = 'e916';
var svgPathData = 'm3.4 120.2 62.2 1.4 95 1.9 71.8 1.1h119.8l71.9-.6 5.4 82.6L437 311l36 .7 38.9-.5-16 53-5.4 10.3L446 380l-3.9 5.2-14.7-1.8-12.6 8.4.7-11.7 9.8-9.9-4.5-9.5-12.2-8.9 14.4-6-19-6-7.3 4-16.2-17.4-7.9-.6-9.8-17.4 10-6.3-3.7-13 19.1-1.5-14.6-13.5-12-5.3 5-11.8 11.4 3.7-1.1-20.9-17.7.8 4.3-8.4 14 3.3-8.6-25.6 10.3-25.8 17.4-12.5 7-23-14.4 3.2 1 13.6-23 19.1-11.8 4.6-5 12.5-.1 22.2-4.3 10.6 3 6-7.4 13.2 2 5.5-6.9 10.4 5.4 19.1 2.2 19.7 13 14.3-.3 25 7.6 11.8-8.4 5.2-10.3-1.8-12.9-14.6-29.8-6.2-14-12.7-5.7-15.4-22.2 12.6-5-3.4-2.7-14.7L258 298l14.2-10.5-2-7.5 10.6-7.7.2-9.5 15.2-15.2-15.2-15.2-12.2 4.5-22.2-14.8-14-2-7.4-10.5 8-11.6-18-11.7-16-4.7.4-13.3-14-21-15.2-6.2-7.4-9.7-10.7-4.1-11 11.2-9.7-3.4-7.9 2.3-5.8 15.8-11-.6-29.6-10.9-15.5 21.7-14.3-5L31.9 174 0 196.5Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faMaryland = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;