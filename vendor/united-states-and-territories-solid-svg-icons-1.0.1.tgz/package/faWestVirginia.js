'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'usat';
var iconName = 'west-virginia';
var width = 448;
var height = 512;
var aliases = ["wv"];
var unicode = 'e936';
var svgPathData = 'm4.8 313 5.8 2 19-4.8L33 295l9.5-1.7.8-13.4-3-10.2 6.7-5.2.3-6.8 9.9-14.6 17.5 11.4 5.8-4.2 2.6-24.9 7.2-11.3 9.9.9 1.2-8.4 9.3-8.2 9.8 7.6 11.3-4.7 18.3-19.5 13-8 1.4-15.6 6.5-13-.9-6.4 5.8-6.1L179 111l9.4-19.1V72.5l-6-10.7 3.5-5.5 9.7-2.2v108l94.4-.7-.2 60.6 24.6-18.9 11.7-12.9 11.5 3.5 11.6-17.7 23.7 7.7h8.9l4-12.6 14 .2 8.4-9.2 8.5 2.9 6.2 7.4 12.2 4.4L447 193l1 15-6.8 19.4-48.3-38 1 13.3-7 11.5 1.7 10.5-15 16.3-2.5 8-16.8 9.7-7.2 14.5-11.6-10-12.2 23.4-7 19-9.2 9.6-15.2-5.1-5.7-11-10.4-4.6-3.5 18.8-11 15-12.2 20.5 1.7 2.9-7 13.5-14.7 14-12.4 21.5 3.6 11.3-3.8 10.3-16.4 10.1-7.2-6-14.3 9.3h-7.3l-15.4 11.6-15.4 2-10.6 5-12.7-12.1-18.7 15.2-11 .5-7.8-8.8-8.6-1.6-5.8-7.3-4.6-23.2-8.8 1L41 407.2l-8.3-4.5-11.4-18.8-2.1-7.7-7.3-5.6-4.2-16.3-7.8-8.2L6 331.6Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faWestVirginia = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;