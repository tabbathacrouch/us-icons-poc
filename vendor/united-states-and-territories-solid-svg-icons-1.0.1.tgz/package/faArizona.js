'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'usat';
var iconName = 'arizona';
var width = 448;
var height = 512;
var aliases = ["az"];
var unicode = 'e904';
var svgPathData = 'm38.4 368 12.8-2.7 4-6.8-2-13.6-10.9-2-2.3-4.7 2.5-13.5-2.7-10.2L53 302.8l2.2-11.4-2-18 8.1-14.1 10.7-5 7.8-10-13-12-8-20.9-10-13.8.2-11.2 4.7-10.4-1.3-12.8-5-13.9 2-8.8-3.2-8 .8-15-3-14.4 8-4.3 16.5.4 8.5 10.4 5.2-.6 7.2-13.3 1-63.5 76.8 1.4 60.6.3 87.8-.1 89.6-1.8 1.7 69.4 2.4 91 2.6 105 1.7 66.8 1.3 54.1 1.4 59.5-64 1.3-72.2.9-78.6-29.3L143 429l-41.4-16-70-27.4.6-9.7Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faArizona = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;