'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'usat';
var iconName = 'tennessee';
var width = 512;
var height = 512;
var aliases = ["tn"];
var unicode = 'e92e';
var svgPathData = 'm31.2 241 8.6-9-.6-13.5 12-13.7 81 2.1-.9-13.4 12.9 3.6 90-.5 29.8 2 37.7-.7 38.7 1.6 50.6-.1 4-1.3 43.5-1 56.5-2.4 17-2-4.9 14.9-9.5 8.6-6.9 13.8-15.3-.5-9.8 9.8-10.4-3.8-16.4 11-4.4 11.3-14.7 4-15.1 12.5-16.5.5-14.3 11.5-.2 8.2-16 6L356 318l-64.3 1.4-89.4-.5-81.1-2.2-57.8-.3-41.8-1.4L0 312l8.5-14.1-2.6-16.5 14-14.9L32 248Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faTennessee = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;