'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'usat';
var iconName = 'minnesota';
var width = 384;
var height = 512;
var aliases = ["mn"];
var unicode = 'e919';
var svgPathData = 'm4 58.7 73 2.1 30.6.5.3-29.3 9.7 1.2 6.6 5.8 6.8 31.2-.5 7.8 5.2 4.9 16.3 1.5 1 3.4 20.2 1.7 2.5 8.7 16.5-2.4 6-6.2h18.2l13 6.1 3.9 7.7 7.4-1 7.4 17.2 3.9-9.5 14.6 1.3 15.1 15.2 14.5 4.6 9-3 18-13.1 6.8 11 31.9-2.7 12.4 8.8 5.7 7-9 5.1-28.2 11.2-16.2 11.7-14.8 14.8-4.2 7-26.5 26.9-16 12.3-5.9 10.7-4.1-1.2 1 45-3.5 4.8-18 9.4-8.3 13.7-.6 10.8 6 .6 6.8 9.4-5.7 11.6 1 26.9-2.9 14.2 20.4 14.7 4.9-.5 7.4 8.9 16 7.5 3 10 16.4 12.7 7.8 1.7 11.5 16.8-1 12.2 3.2 8.6L280 478l-72.2 1.6-72.1.3-48-.4-56.2-1.2 2-73 1.7-63.7-11.9-9-9-15 15.3-16.4 1.9-19.6-1.9-18.7-6-8.6L20 238l1.4-16.5-2.9-41.5.8-15-7.8-20.1-5.6-21 1.8-45Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faMinnesota = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;