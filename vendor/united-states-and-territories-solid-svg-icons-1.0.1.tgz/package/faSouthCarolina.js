'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'usat';
var iconName = 'south-carolina';
var width = 512;
var height = 512;
var aliases = ["sc"];
var unicode = 'e92c';
var svgPathData = 'm40.3 88.6 42.1-12.1L112 64l11.4 2L245 73l.2 12.7 10.6-7.6 15 20.9-1.5 14 111.4 1.1 43 42.3 71.6 70.4-24.7 12.8-14.1 14.2-14.4 19.2-6.1 12.8-4.3 25.3-13.6 10.3-3.1 9.4-17.3-3-8.5 10.2 3.8 5.5-11.8 6.8-2.9 5.5-15.4 6.9-.7 8.2-11.5 9.4-12.3 2L317 396l-15.5 2.1 5.6 8.6-2.4 8.2-17.4 7.8-8.6-8-5.9 4.7 9.6 8.7-7 8.2-10.4 3.4-6.7 8.4-9.9-6.5L237 440l-4.2-15.6 3.6-7.4-8.5-14.3.6-5.4-8.3-10.7-11-4.8-3-12.6v-16.4l-8.3-12.5 1.2-8.2-12.4-10.9-15-7.8-.4-6.9-8.5-4-1.6-7.9-7.6-6.1 3.3-9-13.3-15.3-15-8.2-5-14.9-9.7-10-21-13.7-3.7-10.4-11.9-14.7L75 180l-9-14.1-2.8-11.4L43 149l-9.6-11-16.7-12 1.7-12 15.8-15.6Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faSouthCarolina = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;