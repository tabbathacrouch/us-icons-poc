'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'usat';
var iconName = 'massachusetts';
var width = 512;
var height = 512;
var aliases = ["ma"];
var unicode = 'e915';
var svgPathData = 'm470.2 404.8 22-3 8.6-13.6 9 17.1-7.7 8-15-.5Zm-87.5-10.5 10-1.3 9.7-15.7 13.9-9.5 5.8 2.5 2.5 10.2 14-1.1.5 12.9-35 2.3-16 6ZM36.9 124.2l138.3 6.2 76.3 3 63.9 1.7 6.8-8.8 9 1-.7-10.3 7.5-6 9.7 2.9 4.6-10.2 14-5 16.1 6.3 6.2 30.6 12.1 6.7 7.7-6.8 4.5 10.6-4.2 6.7-10.5 5.5-21.3 5.5 2 9.9-16.7 10-10 27.5 11.4 10.5 5.8-5.2 22.2 3.9 17.8 30.9-.4 8.2-7.7 11.4 7.6 7.2 14.7 4.2 2.9 13-2.1 8.3 10 10.2 10.4 3.7 8.5 7.6 13.1-1.4 4.8-7 27.3-9 2.9-4.1-1.8-18.7-9.2-7-3-17.2 9 2.7 7 13 6.2 20 2.4 32-37.4 6.6-7.3 3.9-27.4 5-8 10.3-25 4 4.6-22.4L407 323l-7.2 2.8-13.6 15-17.3 2.4-.4 12.4-15.3 10-11.4.1-2-31.2-9.1-2.8-9.5-14.8-9.6-5.4-7.8-21.6-.1-24.2-55 1.9-5-2.7-47.8-1.4-123.4-2.7-71-3.3-1.5-7Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faMassachusetts = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;