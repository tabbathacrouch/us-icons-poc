'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'usat';
var iconName = 'pennsylvania';
var width = 512;
var height = 512;
var aliases = ["pa"];
var unicode = 'e929';
var svgPathData = 'm8.2 139.1 16.5-6.3 49.7-26-.7 31.5 76.6 1.5 90.1.5 61.1-.3 67.5-.7 85-2 8.7 14.6 13 2.8 5.7 10.4 1.3 15.7 5.6 12.7 8.6 7.7 11.4 1.4.8 8.9-7.2 8.3-3.4 11.3-12.2 16.8-8.9 6 7.2 13.4-10 11.5-2.6 10 1.3 13.4 11.2 3.6 1.3 14.4L512 343l-3.6 10.3-22.5 18.1-4.4 7.9-25.3 13.5-18.1-3.3-13.7 13.4-57.7 1.2-94 1-56.3-.2-129.6-1.3L0 401.3l2.8-87.5 2.8-90Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faPennsylvania = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;