'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'usat';
var iconName = 'new-hampshire';
var width = 320;
var height = 512;
var aliases = ["nh"];
var unicode = 'e921';
var svgPathData = 'm178.5 56.8 16.2-43.6L208.5 0l7.7 10.2 21 .5 7 116.2 3 61.8 4.1 107.8L254 340l3.1 3.8-5 26.9 3 13.8 12.3 14 9.2 6.7-1 21.8 17.7 13-20.4 39.3-12-4.6-14.3 5.2-4.7 10.4-9.9-3-7.7 6.1.7 10.5-9.2-1-7 9-99.3-3.3-68.9-3.2L29.1 490l-2.4-9.5 4.9-12.8 11.6-18-3.1-8.3 4.6-6.6-3-11.8 3.4-22 5.8-10.7-2.5-9.8 5-25.6 1.1-17 6-3.8 4.8-21 9.3-7.7 7.1-11.5-.4-10L94.1 264l-2.5-7.3 12-19-4.6-19.3-.2-16 12.3-13 15.3.2 8.4-4 3.1-8.4 10.7-1.8 19.3-18.6 3.9-12.9-.4-11.9-4.7-5.4-6.4-18.6 7.2-6.4 4.8-16 6.9-8.4-6-15.4Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faNewHampshire = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;