'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'usat';
var iconName = 'new-york';
var width = 512;
var height = 512;
var aliases = ["ny"];
var unicode = 'e925';
var svgPathData = 'M2.6 295.4 23 284.2l9-7.5 11-4 6.9-11.5 11.7-6.5-3.5-16-5-2.8-1.8-23.3 13-4.5 23-4.5 24.1.7 21.5 3.6 11.3 8.7 14.9-2.8 24.5 1.3 16.2-6.3 18-15 13-4.4-2-20.8 6.7-10-10.5-7.7-4.2-7.3 3.6-8.1 24.8-14.4 9.1-12.7 28.2-27.7L306.8 68l17.6-1.6 32.8.3 49-2.7 1 17.8-3 16.2 5.9 12-.3 17.5-7.3 20 6 23.4-4.5 12 7.9.6 3.6 8.4-.4 59.8 1 7.6-14 57.3 1.4 3.1L401 385l4.6 7-15.7 10 4.6 11.3 28.3 4.8 11.1-5.4 27.3-2.4 15.2-10.4 20 8.3 8.5-7.2 5.6 1.4-38 19.6-47.8 19.7-23.7 5.2-27.4 1.2-1.8-16.1 6.9-20.8-64.5-37.2-10.2-15.5-4.6-19.4-9.6-2.3-6.2-11.1-63-.2-95.5-1.8-66.8-2.1-56.8-2.7Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faNewYork = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;