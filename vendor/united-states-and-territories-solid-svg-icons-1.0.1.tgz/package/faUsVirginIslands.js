'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'usat';
var iconName = 'us-virgin-islands';
var width = 384;
var height = 512;
var aliases = ["vi"];
var unicode = 'e932';
var svgPathData = 'm198.3 32.2.5-6.4 22.8-14 6 2.2 9.5-9 14.7 2 7.7-3.5 6.7 8.7-3.3 11 5 8.9-2 12.7-6.5 3.3-6.3-9-8.2 2.6-11-6.8-6 5.6-12.4-2.6-6 6.9Zm-74 479.8 12.5-15.8 1.4-11.1-7.2-22.7 11.3-16.4 27 5.9 14.5-4.3L194 439l18.3-3.6 21 .3 12.5 15.6 15.3 11.3 8.1.6 13.3-10.6 28.2 1.4 19.5-1.3 4.7 4.4 21.6-4-2 10.4h-17.7l-4.8 6.6-28.7 9.9-29.8 13.4-24.6 1.5-26.2 4.5-14.5.7-29.3 7.3-40.3.4ZM27.5 13.5l6.8-5.1 24.4-1L63.9 0l23.8 2 21.8 6.3 2.6-7.1 12.9 4 9.5 7.7 14.6 2.7 13.6 13-2.6 10.6-16.3 1.5-15.8 5.2-14.6-7.7-4.9-14.6-18.2 3.7-3.8 5.6-15-13.4L59.8 15l-4.2 3.9-19 2.9Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faUsVirginIslands = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;