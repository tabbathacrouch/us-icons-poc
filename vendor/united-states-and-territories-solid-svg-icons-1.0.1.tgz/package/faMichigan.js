'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'usat';
var iconName = 'michigan';
var width = 448;
var height = 512;
var aliases = ["mi"];
var unicode = 'e918';
var svgPathData = 'm339.8 185.3 12-9 7.5 8-14.8 3.8ZM194.2 475l10.6-8.8 7.2-15.5 6.7-9.2 5.2-13.7 2.7-17.5-2.1-25.7-13.8-37 5.5-16.2-3.9-14 12.4-19.6 2-24.8 7-2.4 1.3-11.2 6.6-4.3 13.7-.3.3 13.6 5.6 2 6.4-12.6 1.2-23.4 16-11.3-4-9.2 16.6-15.2 14.2 9 12.6 1.3 7.7 10 25.3 8.4 7.7 6 3.5 9.7-7 9.1 7.4 8 2.3 11.2L369 297l-10.5 8-.8 8.5-16.5 13.3.1 16.4 11.5 6.2 9.1-8 11.2-19.4 16.2-6.8 9.7 5.3 6.5 14 4.6 23.8 1.3 14.1 6.1 17-4.7 25.6-6.8 2.8-7.8-4.7-3.3 16.8-11.8 11.3v10.2l-6.4 10.5-8.8 8.9-.7 5.5-69.3 3.6v-4.4l-50.6.1ZM89.3 51.5l4.1-4.3L123.1 32l-6 11-15.7 6.4-7.6 5.5ZM30.6 138l18.8-6.3 8.9-7.9 20.5-2.3 13.3-9 7.3-.5 4.9-7 15-9.2 7.4-8.3 11.5-5.7 17.7-.5-.8 6.1-11.4 5.6-8.8 7.4-10.3 14.5.2 12.1 9.2-9 16.2 2 12.2 7 5.9 11.5 8.8 10.9 15.8-2 7.5 6.2 8.4 2 4.2-5.8 19.6-12h30l11.6-5.3 12.2-1.3-2.7 17.7 13.6 4 6.5-2.1 24.5-1.6-1.2 22.3 10.8 14.4-20.7 1-14.4-6.4-7.7 12.7-8.8-9.4-20.2-6.5-11 9.3-12.8 2.3-13-2.3-6 3.9-2.4 8-7.5-4.5-12.1-.7-3 9.6-10.3-1.4-9.6 11.5-3.8 9.3-10.7 16-9.5.9 4.5-11-11.4-2 5.8-16.3-4.7-10.6-10.2-2.5-2.2-10.5-30-6.6-14.4-9-48.1-16.2-3.9-11.5Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faMichigan = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;