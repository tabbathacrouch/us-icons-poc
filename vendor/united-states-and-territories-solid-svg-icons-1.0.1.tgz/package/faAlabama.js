'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'usat';
var iconName = 'alabama';
var width = 384;
var height = 512;
var aliases = ["al"];
var unicode = 'e901';
var svgPathData = 'M59.3 1.3 59.1 0l118.6 2.5 111.3.2 12.8 70.7 11 62.3 16.9 94.7 7.6 24.3 12.5 21.6-2.5 13 6.7 11-11.9 9.6.9 13.2-7.5 16.5 1.6 17.7 8 16.5-6.1 30 1.3 10.6 6.1 6.1 3.3 11.6-82.5 1.8-58 .4-99.8-.7-3.4 14.2 9.3 13.3 11.7 7.4-3.8 16 1.5 13-12.1 14.5-17.6-2-14.7-13.2-1.5-25.8-7.5-3.7L64 479l-2.5 21-7.4 1.6-14-4.8-5.4 3.8-2.6-94.8-2.1-70 7.2-59.7 7.6-67.4 12.2-103 11.2-93Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faAlabama = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;