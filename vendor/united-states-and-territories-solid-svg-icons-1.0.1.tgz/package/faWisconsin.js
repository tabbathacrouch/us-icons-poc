'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'usat';
var iconName = 'wisconsin';
var width = 448;
var height = 512;
var aliases = ["wi"];
var unicode = 'e935';
var svgPathData = 'M81.4 54.6 97 56l31.4-11.8 16.8-4.1 9.1-8.2 11.9 1.1.4 9.3-7 8.5-1.9 17.5 13.8-8.3 22 13.6 12.2 3.2 6.6 16.6L284 113l21.7 12 11.7 2.7 7.4-3.3 6.5 4.3 19 3.4 5 7.3-1 8 15.2 2.7 4.8 4.2 3 11-2.3 14-4.9 10.2 16.9 2-5.8 16.4 10.4 8-2.3 11-13 3.7-1.1 6-10.4 17.7-3.2 16.5 7.5 2 5-8.5 6.5-2.4 10.5-20 14.4-7.2 11-27 14-6.8-1 10.8-8.8 16-.8 9.4-7.8 9-11 28.4-3.8 19.2 2.3 14.2-9 8-5.8 22.5 3 19.4-6 12.8-.8 10-4.6 7.8-2.7 13.9 4 18 2 19.8 6.6 9-4 14.9 1.5 14.3-73.1 1.6-95.6-1-42.3-.2-5.6-13.4-17.2-4.8-7.2-5.1-3.5-14.8-3.3-2.7-2-22 9-12.6-10.4-9.7-1.9-23.4-2.6-3.5 2-16-2.8-7.3-11-15.7L106 325l-9-9.6-11.7-8.3-3.4-13.5-9-7-11.5-4.1-9.2-12.2-6.4.2-13-9L20 249.6l4.7-18.6-2.4-14.4 3.4-2.8-.3-18.4 8.4-15-8.3-12.8-8-1.2 1.6-14.2 6-4.5 5.9-13 24.5-11.1 5-6L62.2 58l5.5 1.8 8.7-9.8Z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faWisconsin = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;